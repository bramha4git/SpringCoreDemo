package com.example.SpringCoreDemo.methodInjection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MethodInjectionTest {

	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("methodInjection.xml");
		RequestProcessor processor = (RequestProcessor) applicationContext.getBean("processor");
		for (int i = 0; i < 3; i++) {
			ResourceA resource = processor.getResourceA();
			System.out.println(resource.getUrl());
		}
		for (int i = 0; i < 3; i++) {
			ResourceB resource = processor.getResourceB();
			System.out.println(resource.getUrl());
		}
	}

}
