package com.example.SpringCoreDemo;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.example.SpringCoreDemo.beans.BeanFactoryBean;

public class BeanFactoryTest {

	public static void main(String[] args) {
		XmlBeanFactory factory = new XmlBeanFactory(new ClassPathResource("beanfactory.xml"));
		BeanFactoryBean obj = (BeanFactoryBean) factory.getBean("bean-factory-message");
		obj.getMessage();
	}

}
