package com.example.SpringCoreDemo.beans;

import org.springframework.beans.factory.annotation.Autowired;

public class SingletonBean {

    @Autowired
    private PrototypeBean prototypeBean;

    public void showMessage(){
        System.out.println("Hi, the time is "+prototypeBean.getDateTime());
    }
}