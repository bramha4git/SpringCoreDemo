package com.example.SpringCoreDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.SpringCoreDemo.beans.BeanScopeBean;

public class BeanScopeTest {
	
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("beanScopeConfig.xml");
		
		BeanScopeBean beanScopeBean1 = (BeanScopeBean) context.getBean("beanScope");
		beanScopeBean1.setWelcomeNote("object 1 setting the property");
		beanScopeBean1.greetCustomer();

		BeanScopeBean beanScopeBean2 = (BeanScopeBean) context.getBean("beanScope");
		beanScopeBean2.greetCustomer();
	}
	
	

}
