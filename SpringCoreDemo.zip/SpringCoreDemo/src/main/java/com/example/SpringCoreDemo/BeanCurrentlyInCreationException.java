package com.example.SpringCoreDemo;
//circular dependency and BeanCurrentlyInCreationException
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.stereotype.Component;

@ComponentScan(basePackageClasses = BeanCurrentlyInCreationException.class, useDefaultFilters = false,
		includeFilters = { @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = { BeanCurrentlyInCreationException.BeanB.class,
				BeanCurrentlyInCreationException.BeanA.class }) })
@Configuration
public class BeanCurrentlyInCreationException {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(BeanCurrentlyInCreationException.class);
	}

	@Component
	public static class BeanA {
		private final BeanB beanB;

		public BeanA(BeanB b) {
			this.beanB = b;
		}
	}

	@Component
	public static class BeanB {
		private final BeanA beanA;

		public BeanB(BeanA beanA) {
			this.beanA = beanA;
		}
	}
}