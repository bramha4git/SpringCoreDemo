package com.example.SpringCoreDemo.beans;

public class AutowiringByTypeCountry {

	String countryName;

	Capital capitalObj;

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public Capital getCapitalObj() {
		return capitalObj;
	}

	public void setCapitalObj(Capital capitalObj) {
		this.capitalObj = capitalObj;
	}

}
