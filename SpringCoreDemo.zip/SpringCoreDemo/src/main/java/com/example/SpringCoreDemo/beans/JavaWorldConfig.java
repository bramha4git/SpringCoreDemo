package com.example.SpringCoreDemo.beans;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JavaWorldConfig {
	@Bean
	public JavaWorld javaWorld() {
		return new JavaWorld();
	}
}