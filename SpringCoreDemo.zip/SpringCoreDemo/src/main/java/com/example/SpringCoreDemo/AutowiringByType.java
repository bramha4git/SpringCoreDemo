package com.example.SpringCoreDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.SpringCoreDemo.beans.AutowiringByTypeCountry;

public class AutowiringByType {

	public static void main(String[] args) {
		ApplicationContext appContext = new ClassPathXmlApplicationContext("AutowiringByTypeConfig.xml");
		AutowiringByTypeCountry countryObj = (AutowiringByTypeCountry) appContext.getBean("country");
		String countryName = countryObj.getCountryName();
		String capitalName = countryObj.getCapitalObj().getCapitalName();
		System.out.println(capitalName + " is capital of " + countryName);

	}
}