package com.example.SpringCoreDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.SpringCoreDemo.beans.SetterBean;

public class SetterDependencyInjection {
	
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("setterInjectionBean.xml");
		
		SetterBean customerObj = (SetterBean) context.getBean("setterBean");
		 
		customerObj.greetCustomer();
		
		SetterBean customerObj1 = (SetterBean) context.getBean("setterBean1");
		 
		customerObj1.greetCustomer();
		
		((AbstractApplicationContext)context).registerShutdownHook(); // to destroy all the beans before main mathod ends

	}

}
