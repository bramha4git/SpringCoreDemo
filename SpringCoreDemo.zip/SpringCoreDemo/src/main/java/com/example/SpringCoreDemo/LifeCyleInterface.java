package com.example.SpringCoreDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.SpringCoreDemo.beans.AwareBeanImpl;

public class LifeCyleInterface {
	
	public static void main(String[] args) {
		ApplicationContext context1 = new ClassPathXmlApplicationContext("lifeCycleInterfaceConfig.xml");
		AwareBeanImpl awareBeanImpl = (AwareBeanImpl) context1.getBean("awareBean");
		((AbstractApplicationContext) context1).registerShutdownHook();
		}

}
