package com.example.SpringCoreDemo.serviceLocatorPattern;

public interface Service {
	public String getName();

	public void execute();
}