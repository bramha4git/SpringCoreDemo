package com.example.SpringCoreDemo.beans;

public class SetterBean {
	
	private int id;
	private String customerName;
	
	
	public void setId(int id) {
		this.id = id;
	}
	
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
  
	public void greetCustomer() {
		System.out.println("customer id is:::"+id+ " \ncustomer name is::"+customerName);
	}
	
	public void init() {
		System.out.println("running in init method");
		
	}
	
	public void destroy() {
		System.out.println("destroyed method");
		
	}
	
	
}
