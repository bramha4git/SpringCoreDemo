package com.example.SpringCoreDemo.beans;

public class BeanScopeBean {

	private String welcomeNote;

	public void setWelcomeNote(String welcomeNote) {

		this.welcomeNote = welcomeNote;
	}

	public void greetCustomer() {

		System.out.println(welcomeNote);
	}
}