package com.example.SpringCoreDemo;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
/*
postProcessAfterInitialization – Apply this BeanPostProcessor to the given new bean instance after any bean initialization callbacks.
postProcessBeforeInitialization – Apply this BeanPostProcessor to the given new bean instance before any bean initialization.
*/
public class BeanPostProcessorExample implements BeanPostProcessor {

    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        System.out.println("Calling bean post processor before init for bean:: "+beanName + "class name: "+bean.getClass());
        return bean;
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
                System.out.println("Calling bean post processor after init for bean:: "+beanName + "class name: "+bean.getClass());
        return bean;
    }
}