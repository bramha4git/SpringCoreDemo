package com.example.SpringCoreDemo.beans;

public class FilexmlapplicationCOntextBean {
	 
	    public void sayGoodMorning(){
	        System.out.println("Hi, Good Morning!");
	    }
	    public void sayGoodEvening(){
	        System.out.println("Hi, Good Evening!");
	    }
	    public void sayGoodNight(){
	        System.out.println("Hi, Good Night!");
	    }

}
