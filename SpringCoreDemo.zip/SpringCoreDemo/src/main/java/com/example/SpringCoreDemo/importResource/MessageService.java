package com.example.SpringCoreDemo.importResource;

public interface MessageService {
	public void sendMsg(String message);
}