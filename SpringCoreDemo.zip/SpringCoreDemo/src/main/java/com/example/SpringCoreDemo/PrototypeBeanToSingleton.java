package com.example.SpringCoreDemo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.example.SpringCoreDemo.beans.PrototypeBean;
import com.example.SpringCoreDemo.beans.SingletonBean;

@Configuration
public class PrototypeBeanToSingleton {

	@Bean
	@Scope("prototype")
	public PrototypeBean prototypeBean() {
		return new PrototypeBean();
	}

	@Bean
	public SingletonBean singletonBean() {
		return new SingletonBean();
	}

	public static void main(String[] args) throws InterruptedException {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(PrototypeBeanToSingleton.class);
		SingletonBean bean = context.getBean(SingletonBean.class);
		bean.showMessage();

		bean = context.getBean(SingletonBean.class);
		bean.showMessage();
	}
}