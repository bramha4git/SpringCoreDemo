package com.example.SpringCoreDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.SpringCoreDemo.beans.ConstructorBean;

public class ConstructorDependencyInjection {
	
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("constructorInjectionBean.xml");
				
		ConstructorBean constructorBean = (ConstructorBean) context.getBean("constructorBean");
		 
		constructorBean.greetCustomer();
		
	}

}
