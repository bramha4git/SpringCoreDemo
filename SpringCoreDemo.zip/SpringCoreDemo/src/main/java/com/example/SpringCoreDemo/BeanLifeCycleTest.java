package com.example.SpringCoreDemo;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.SpringCoreDemo.beans.LifeCycleBean;

public class BeanLifeCycleTest {
	
	public static void main(String[] args) {
	      AbstractApplicationContext context = new ClassPathXmlApplicationContext("beanLifeCycle.xml");

	      LifeCycleBean obj = (LifeCycleBean) context.getBean("life-cycle");
	      obj.getMessage();
	      context.registerShutdownHook();
	   }

}


