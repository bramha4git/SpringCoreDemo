package com.example.SpringCoreDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.example.SpringCoreDemo.beans.FilexmlapplicationCOntextBean;

public class FileSystemXmlApplicationContextTest {

	public static void main(String[] args) {
		ApplicationContext context = new FileSystemXmlApplicationContext("d:/beans.xml");
		FilexmlapplicationCOntextBean hello = (FilexmlapplicationCOntextBean) context.getBean("hello");
		hello.sayGoodMorning();
		hello.sayGoodEvening();
		hello.sayGoodNight();
	}

}
