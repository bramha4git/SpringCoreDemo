package com.example.SpringCoreDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.example.SpringCoreDemo.beans.JavaWorld;
import com.example.SpringCoreDemo.beans.JavaWorldConfig;

public class JavaBasedConfiguration {

	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(JavaWorldConfig.class);

		JavaWorld javaWorld = ctx.getBean(JavaWorld.class);
		javaWorld.setMessage("JAVA based configuration is done!!");
		javaWorld.getMessage();
	}

}
