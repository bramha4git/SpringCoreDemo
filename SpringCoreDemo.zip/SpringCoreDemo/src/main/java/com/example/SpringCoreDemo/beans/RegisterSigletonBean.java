package com.example.SpringCoreDemo.beans;

public class RegisterSigletonBean {
	public void print() {
		System.out.println("Register Outside Container");
	}
}