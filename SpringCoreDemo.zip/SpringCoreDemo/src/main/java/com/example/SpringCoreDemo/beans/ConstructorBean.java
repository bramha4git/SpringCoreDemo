package com.example.SpringCoreDemo.beans;

public class ConstructorBean {
	
	private int id;
	private String customerName;
	
	
	public ConstructorBean(int id, String customerName) {
		this.id = id;
		this.customerName = customerName;
	}
	
	
	public void greetCustomer() {
		System.out.println("customer id is:::"+id+ " \ncustomer name is::"+customerName);
	}

}
