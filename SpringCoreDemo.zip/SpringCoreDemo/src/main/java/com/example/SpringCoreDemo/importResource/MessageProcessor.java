package com.example.SpringCoreDemo.importResource;

public interface MessageProcessor {
	public void processMsg(String message);
}