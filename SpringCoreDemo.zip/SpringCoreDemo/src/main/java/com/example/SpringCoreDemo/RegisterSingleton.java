package com.example.SpringCoreDemo;

import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.SpringCoreDemo.beans.RegisterSigletonBean;

public class RegisterSingleton {

	public static void main(String args[]) {
		ConfigurableApplicationContext applicationContext = new ClassPathXmlApplicationContext("");
		ConfigurableListableBeanFactory beanFactory = applicationContext.getBeanFactory();
		beanFactory.registerSingleton("simplebean", new RegisterSigletonBean());
		RegisterSigletonBean bean = (RegisterSigletonBean) applicationContext.getBean("simplebean");
		bean.print();
		applicationContext.close();
	}

}
