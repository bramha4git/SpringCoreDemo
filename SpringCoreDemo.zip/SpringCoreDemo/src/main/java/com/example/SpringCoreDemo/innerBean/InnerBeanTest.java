package com.example.SpringCoreDemo.innerBean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class InnerBeanTest {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("innerBean.xml");
		TextEditor texted = (TextEditor) context.getBean("textEditor");
		texted.spellCheck();
	}
}
