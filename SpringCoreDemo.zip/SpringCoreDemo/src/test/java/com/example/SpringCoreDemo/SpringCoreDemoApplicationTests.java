package com.example.SpringCoreDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCoreDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
